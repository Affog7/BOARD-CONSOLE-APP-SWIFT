//
//  main.swift
//  ConsoleApp
//
//  Created by etudiant on 18/01/2023.
//

import Foundation
import SwiftPackage

 

var bd = Board(withGrid: [[3,2],[2,nil],[2,2],[2,2]])

var players = Human(name: "Joueur1", id : 12 ))


print(players.getName())
 
